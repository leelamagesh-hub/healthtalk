# Health Talk

A simple two-page health education site for teens, plus a console version of the chatbot.

## Files

- `index.html` — Landing page / info guide on puberty and health
- `chat.html` — Keyword-based chat box (40+ topics), linked from the landing page
- `health_talk.py` — Standalone console version of the same chatbot logic

## Running locally

Just open `index.html` in any browser — no server or build step needed.
To try the console version: `python health_talk.py`

## Deploying

These are plain static files, so any static host works:

- **GitHub Pages** — push this folder to a repo, enable Pages in Settings
- **Netlify Drop** (app.netlify.com/drop) — drag the folder in, get a live link instantly
- **Cloudflare Pages** or **Vercel** — same drag-and-drop style deploy

The two HTML pages already link to each other using relative filenames
(`chat.html` and `index.html`), so navigation works as-is on any host —
no links to update.

## Customizing

- Colors are defined as CSS variables at the top of each `<style>` block
  (`--blue`, `--navy`, `--sky`, `--ink`, etc.) — change them there to re-theme.
- Chat answers live in the `questions` object in `chat.html` (and the matching
  dict in `health_talk.py`) — add new `"keyword": "answer"` pairs to expand it.
