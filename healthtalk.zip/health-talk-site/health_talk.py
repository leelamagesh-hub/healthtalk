import random
import re

print("Welcome to Health Talk! 💬")
print("I'm here to chat about puberty, hygiene and teen health — ask me anything.")
print("Type 'exit' to stop.")

# Each topic carries its canonical answer plus every synonym, slang term or
# "code word" a teen might actually type for it, so the bot recognises
# casual phrasing and not just clinical terms. `related` topic ids are used
# to suggest a natural follow-up question.
topics = [
    {"id": "puberty", "keys": ["puberty", "growing up", "hitting puberty", "changing body", "body changes",
                                "am i normal", "is this normal", "puberty timing", "late bloomer", "early bloomer"],
     "a": "Puberty is the stage when a child's body gradually develops into an adult body — it's triggered by "
          "hormones and the timing is different for everyone, so starting earlier or later than friends is "
          "completely normal.",
     "related": ["hormone", "growth", "mood"]},

    {"id": "acne", "keys": ["pimple", "pimples", "acne", "breakout", "breakouts", "zit", "zits",
                             "spots on my face", "spots on face"],
     "a": "Pimples and acne happen a lot during puberty because hormonal changes increase oil production in "
          "the skin. Washing your face gently twice a day and not picking at spots both help.",
     "related": ["skin care", "hygiene", "confidence"]},

    {"id": "sweat", "keys": ["sweat", "sweating", "body odour", "body odor", "smell down there", "smelly",
                              "stink", "stinky", "underarm smell"],
     "a": "During puberty, sweat glands become more active, so sweating and body odour can increase — showering "
          "daily and using deodorant usually keeps it well under control.",
     "related": ["deodorant", "hygiene", "feet"]},

    {"id": "hygiene", "keys": ["hygiene", "staying clean", "keeping clean", "cleaning myself"],
     "a": "Regular bathing, clean clothes and good personal hygiene help keep a changing body clean, "
          "comfortable and healthy.",
     "related": ["sweat", "underwear", "teeth"]},

    {"id": "sleep", "keys": ["sleep", "tired all the time", "can't sleep", "insomnia"],
     "a": "Getting enough sleep supports healthy growth, learning, mood and overall well-being — teens "
          "generally need around 8–10 hours a night.",
     "related": ["mood", "stress", "screen time"]},

    {"id": "nutrition", "keys": ["nutrition", "diet", "eating healthy", "healthy food", "what should i eat"],
     "a": "A varied, balanced diet gives your body the nutrients it needs for growth and development during "
          "puberty.",
     "related": ["water", "weight", "exercise"]},

    {"id": "exercise", "keys": ["exercise", "workout", "working out", "sports", "physical activity",
                                 "getting fit"],
     "a": "Regular physical activity supports both physical and mental well-being during adolescence — find "
          "something you enjoy and it won't feel like a chore.",
     "related": ["muscles", "sleep", "mental health"]},

    {"id": "mood", "keys": ["mood", "mood swings", "emotional", "feelings", "crying a lot", "irritable",
                             "moody"],
     "a": "Big swings in emotion are really common during adolescence as hormone levels shift. Talking to a "
          "trusted adult can help when feelings feel hard to manage.",
     "related": ["stress", "anxiety", "mental health"]},

    {"id": "body hair", "keys": ["body hair", "hairy", "hair growing", "more hair"],
     "a": "Growing more body hair — on arms, legs and elsewhere — is a normal physical change that happens "
          "during puberty for everyone.",
     "related": ["shaving", "pubic hair", "facial hair"]},

    {"id": "growth", "keys": ["growth", "growth spurt", "getting taller", "height"],
     "a": "Growth spurts in height are a normal part of puberty, but the timing and speed are different for "
          "every person.",
     "related": ["nutrition", "sleep", "weight"]},

    {"id": "teeth", "keys": ["teeth", "tooth", "braces", "oral hygiene", "brushing", "brush",
                              "brush my teeth", "brushing teeth", "what is brushing", "toothbrush",
                              "toothpaste", "floss", "flossing"],
     "a": "Brushing is cleaning your teeth with a toothbrush and toothpaste — do it for about two minutes, "
          "twice a day (morning and before bed), and floss once a day. It removes food and plaque so it "
          "protects your teeth and gums and keeps your breath fresh as you grow.",
     "related": ["hygiene", "bathing", "confidence"]},

    {"id": "bathing", "keys": ["bathing", "bath", "shower", "showering", "washing myself", "wash my body",
                                "how often shower", "what is bathing", "take a shower", "have a shower"],
     "a": "Bathing means washing your body with water and soap, usually in a shower or bath. During puberty a "
          "daily wash rinses away sweat, oil and germs — pay attention to your underarms, groin and feet — so "
          "you stay clean, fresh and comfortable.",
     "related": ["sweat", "deodorant", "hygiene"]},

    {"id": "hair washing", "keys": ["hair washing", "washing hair", "wash my hair", "greasy hair",
                                     "oily hair", "shampoo", "how often wash hair"],
     "a": "Hair can get oilier during puberty, so washing it with shampoo every day or every couple of days "
          "(whatever suits your hair) keeps your scalp clean and your hair feeling fresh.",
     "related": ["bathing", "hygiene", "skin care"]},

    {"id": "nails", "keys": ["nails", "nail", "fingernails", "toenails", "cutting nails", "dirty nails"],
     "a": "Keeping your nails trimmed and clean stops dirt and germs building up underneath them — a quick "
          "trim and scrub is a simple, useful hygiene habit.",
     "related": ["hand washing", "hygiene"]},

    {"id": "hand washing", "keys": ["hand washing", "washing hands", "wash my hands", "clean hands"],
     "a": "Washing your hands with soap and water for about 20 seconds — especially before eating and after "
          "using the toilet — helps remove germs and stops them spreading.",
     "related": ["hygiene", "nails"]},

    {"id": "periods", "keys": ["period", "periods", "menstruation", "menstrual cycle", "time of the month",
                                "on my period", "first period", "my flow", "menstrual"],
     "a": "Periods are a normal part of reproductive development. Learning about menstrual hygiene — and "
          "trying pads, tampons or other products to see what's comfortable — helps you manage them safely "
          "and confidently.",
     "related": ["cramps", "pads", "discharge"]},

    {"id": "pads", "keys": ["pad", "pads", "tampon", "tampons", "menstrual products", "menstrual cup"],
     "a": "Pads, tampons and menstrual cups are all common period products — trying a few types can help you "
          "find what's comfortable, and a trusted adult or pharmacist can help you choose.",
     "related": ["periods", "cramps"]},

    {"id": "discharge", "keys": ["discharge", "vaginal discharge", "white stuff"],
     "a": "Vaginal discharge is a normal, healthy way the body keeps itself clean — the amount and texture can "
          "change throughout the month.",
     "related": ["periods", "hygiene", "doctor"]},

    {"id": "trusted adult", "keys": ["trusted adult", "who can i talk to", "who to talk to"],
     "a": "If you're worried about a health change or symptom, talking to a trusted adult or healthcare "
          "professional is a great first step — you don't have to figure it out alone.",
     "related": ["doctor", "mental health"]},

    {"id": "hormone", "keys": ["hormone", "hormones", "hormonal"],
     "a": "Hormones are chemical messengers that trigger the physical and emotional changes of puberty — "
          "they're the reason so much changes at once.",
     "related": ["puberty", "mood", "growth"]},

    {"id": "voice", "keys": ["voice", "voice cracking", "voice changing", "deep voice", "cracking voice"],
     "a": "A deepening or cracking voice is a completely normal change during puberty as the voice box grows "
          "— it usually settles down after a while.",
     "related": ["puberty", "confidence"]},

    {"id": "breast", "keys": ["breast", "breasts", "boobs", "chest growing", "chest developing", "developing"],
     "a": "Breast development is often one of the earliest signs of puberty and happens gradually — one side "
          "developing before the other is common too.",
     "related": ["bra", "body image", "confidence"]},

    {"id": "testes", "keys": ["testes", "testicles", "balls", "scrotum"],
     "a": "The testes grow larger during puberty as part of normal male reproductive development.",
     "related": ["penis", "wet dream", "doctor"]},

    {"id": "penis", "keys": ["penis", "private part growing", "genitals growing"],
     "a": "The penis and testes grow larger and change shape during puberty — this happens at different rates "
          "for everyone and is a normal part of development.",
     "related": ["testes", "erection", "wet dream"]},

    {"id": "erection", "keys": ["erection", "erections", "random erection"],
     "a": "Erections can start happening more often, and sometimes without an obvious reason, during puberty "
          "— this is a normal and involuntary part of male physical development.",
     "related": ["penis", "wet dream", "privacy"]},

    {"id": "wet dream", "keys": ["wet dream", "wet dreams", "nocturnal emission"],
     "a": "Nocturnal emissions, or 'wet dreams', are a normal and involuntary part of male puberty — there's "
          "nothing to be embarrassed about.",
     "related": ["erection", "hormone", "privacy"]},

    {"id": "shaving", "keys": ["shaving", "shave", "razor"],
     "a": "Some people choose to shave new body or facial hair — it's a personal choice, not a medical need.",
     "related": ["body hair", "facial hair", "confidence"]},

    {"id": "facial hair", "keys": ["facial hair", "moustache", "mustache", "beard", "stubble"],
     "a": "Facial hair — like the start of a moustache or beard — is a normal change during male puberty and "
          "grows in gradually.",
     "related": ["shaving", "voice", "confidence"]},

    {"id": "pubic hair", "keys": ["pubic hair", "hair down there"],
     "a": "Pubic hair usually starts growing during puberty as hormone levels rise — it's a normal part of "
          "development for every body.",
     "related": ["body hair", "hygiene"]},

    {"id": "deodorant", "keys": ["deodorant", "antiperspirant"],
     "a": "Using deodorant or antiperspirant can help manage increased sweat and body odour during puberty.",
     "related": ["sweat", "hygiene"]},

    {"id": "confidence", "keys": ["confidence", "self esteem", "insecure", "self conscious"],
     "a": "Feeling unsure about a changing body is really common. Confidence usually grows as the changes "
          "become familiar — and everyone's timeline looks different.",
     "related": ["body image", "privacy", "friends"]},

    {"id": "privacy", "keys": ["privacy", "want to be alone", "space from family"],
     "a": "Wanting more privacy during puberty is a totally normal part of growing independence.",
     "related": ["confidence", "trusted adult"]},

    {"id": "cramps", "keys": ["cramps", "cramp", "period pain"],
     "a": "Mild cramping can happen around a period — warmth, rest and gentle movement often help. See a "
          "doctor if the pain feels severe.",
     "related": ["periods", "pads", "doctor"]},

    {"id": "bra", "keys": ["bra", "sports bra", "training bra"],
     "a": "Some people start wearing a bra as breasts develop — a well-fitted one can just be more comfortable "
          "day to day.",
     "related": ["breast", "body image"]},

    {"id": "underwear", "keys": ["underwear", "boxers", "briefs"],
     "a": "Wearing clean, breathable underwear and changing it daily is an important part of personal hygiene "
          "during puberty.",
     "related": ["hygiene", "discharge"]},

    {"id": "feet", "keys": ["feet", "smelly feet", "foot odour", "foot odor"],
     "a": "Washing and drying feet well, and changing socks daily, helps prevent foot odour during puberty.",
     "related": ["sweat", "hygiene"]},

    {"id": "skin care", "keys": ["skin care", "skincare", "moisturiser", "moisturizer", "cleanser"],
     "a": "A simple routine — gentle cleanser, moisturiser and sunscreen — helps keep changing skin healthy.",
     "related": ["acne", "sunscreen"]},

    {"id": "water", "keys": ["water", "hydration", "drink enough"],
     "a": "Drinking enough water supports skin health, energy and overall growth during puberty.",
     "related": ["nutrition", "skin care"]},

    {"id": "weight", "keys": ["weight", "gaining weight", "losing weight", "body weight"],
     "a": "Weight changes are a normal part of growth — a balanced diet and regular activity support healthy "
          "development at every stage of puberty.",
     "related": ["nutrition", "exercise", "body image"]},

    {"id": "muscles", "keys": ["muscles", "getting stronger", "muscle growth", "building muscle"],
     "a": "Increased muscle mass, especially in boys, is a common part of puberty as hormone levels rise.",
     "related": ["exercise", "growth"]},

    {"id": "stress", "keys": ["stress", "stressed", "overwhelmed"],
     "a": "Feeling more stressed during puberty is common as your body and life both change quickly. Talking "
          "to a trusted adult can really help you manage it.",
     "related": ["anxiety", "mental health", "sleep"]},

    {"id": "anxiety", "keys": ["anxiety", "anxious", "worried", "worry"],
     "a": "Increased worry or anxiety can happen during puberty — a trusted adult or counsellor can help if "
          "it ever feels like too much to carry alone.",
     "related": ["stress", "mental health", "trusted adult"]},

    {"id": "friends", "keys": ["friends", "friendships", "social life"],
     "a": "Friendships and peer relationships often shift during adolescence — that's a normal, if sometimes "
          "confusing, part of growing up.",
     "related": ["peer pressure", "confidence"]},

    {"id": "peer pressure", "keys": ["peer pressure", "pressured by friends"],
     "a": "It's okay to say no to anything that feels uncomfortable, even with friends. A trusted adult can "
          "help if you're ever unsure how to handle it.",
     "related": ["friends", "trusted adult"]},

    {"id": "doctor", "keys": ["doctor", "pediatrician", "paediatrician", "gp"],
     "a": "A doctor or pediatrician can answer medical questions about puberty confidentially and accurately "
          "— that's exactly what they're there for.",
     "related": ["trusted adult", "mental health"]},

    {"id": "mental health", "keys": ["mental health", "therapist", "counselor", "counsellor"],
     "a": "Looking after mental health — through sleep, talking to someone you trust, and rest — matters just "
          "as much as physical health during puberty.",
     "related": ["stress", "anxiety", "trusted adult"]},

    {"id": "screen time", "keys": ["screen time", "phone too much", "too much screen"],
     "a": "Balancing screen time with sleep, activity and offline time supports overall well-being during "
          "adolescence.",
     "related": ["sleep", "mental health"]},

    {"id": "sunscreen", "keys": ["sunscreen", "sunblock", "spf"],
     "a": "Using sunscreen daily helps protect changing skin from sun damage.",
     "related": ["skin care", "acne"]},

    {"id": "body image", "keys": ["body image", "comparing my body", "don't like my body"],
     "a": "It's completely normal to notice and compare body changes with others — every body develops on "
          "its own timeline, and that's okay.",
     "related": ["confidence", "weight", "mental health"]},
]

# Longest keyword first, so specific phrases match before short generic ones.
keyword_index = sorted(
    ((key, topic) for topic in topics for key in topic["keys"]),
    key=lambda pair: len(pair[0]),
    reverse=True,
)
topic_by_id = {t["id"]: t for t in topics}

small_talk = [
    (["thank you", "thanks", "thx", "ty"],
     ["You're welcome! Anything else on your mind?", "Anytime! Ask me anything else about puberty or teen health."]),
    (["hi", "hello", "hey", "yo"],
     ["Hey there! What's on your mind today?", "Hi! I'm all ears — ask away."]),
    (["bye", "goodbye", "see ya", "see you"],
     ["Take care of yourself! Come back anytime you have a question.", "Bye for now — I'll be here whenever you need me."]),
    (["who are you", "what are you", "your name"],
     ["I'm the Health Talk chatbot — here to answer everyday questions about puberty, hygiene and teen health in plain language."]),
    (["how are you"],
     ["Doing great, thanks for asking! More importantly — how can I help you today?"]),
]

intros = ["", "", "Good question! ", "Great question! ", "Glad you asked — "]
follow_ups = [
    "Want to know something else?",
    "Anything else you're curious about?",
    "Got another question? Ask away.",
    "Curious about anything related?",
    "Is there something else on your mind?",
]
fallback_replies = [
    "Hmm, I don't have a vetted answer for that one yet.",
    "I'm not totally sure about that specific one.",
    "That's outside what I've got answers for right now.",
]


def contains_key(q, key):
    # Match whole words/phrases only, so short keys like "ty" (thanks) don't
    # match inside longer words like "puberty".
    return re.search(r"\b" + re.escape(key) + r"\b", q) is not None


def match_small_talk(q):
    for keys, replies in small_talk:
        if any(contains_key(q, k) for k in keys):
            return random.choice(replies)
    return None


def match_topic(q):
    for key, topic in keyword_index:
        if contains_key(q, key):
            return topic
    return None


while True:
    question = input("\nAsk your question: ").strip().lower()

    if question == "exit":
        print("Thank you for using Health Talk! Take care 💙")
        break
    if not question:
        continue

    chat_reply = match_small_talk(question)
    if chat_reply:
        print("\n" + chat_reply)
        continue

    topic = match_topic(question)
    if topic:
        print("\n" + random.choice(intros) + topic["a"])
        related = [topic_by_id[i] for i in topic.get("related", []) if i in topic_by_id]
        if related:
            print(random.choice(follow_ups), "I can also tell you about:", ", ".join(t["id"] for t in related))
        else:
            print(random.choice(follow_ups))
    else:
        print("\n" + random.choice(fallback_replies))
        print("I can help with lots of everyday questions about puberty, health and hygiene. For example:")
        print("  • Puberty & body changes: puberty, growth, hormones, voice, body hair, periods")
        print("  • Hygiene: bathing, brushing, hair washing, hand washing, nails, deodorant, skin care")
        print("  • Health & wellbeing: sleep, nutrition, exercise, mood, stress, confidence")
        print('Try asking something like "what is puberty", "what is bathing" or "what is brushing" —')
        print("or bring it to a trusted adult or doctor if you'd like to talk it through with someone.")
